import React, { useState } from 'react';
import { PropertyImage } from '../types';
import ComparisonSlider from './ComparisonSlider';

interface ComparisonModalProps {
  isOpen: boolean;
  onClose: () => void;
  images: PropertyImage[];
}

const ComparisonModal: React.FC<ComparisonModalProps> = ({ isOpen, onClose, images }) => {
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen || images.length < 2) return null;

  const handleCopy = () => {
    if (!analysis) return;
    navigator.clipboard.writeText(analysis);
    alert('비교 리포트가 복사되었습니다.');
  };

  const generateReport = async () => {
    setIsLoading(true);
    setAnalysis(null);

    // 전문가가 분석하는 듯한 UX 연출
    await new Promise(resolve => setTimeout(resolve, 1200)); 

    const report = `## 🏙️ 유니시티 프리미엄 매물 정밀 비교 리포트

**여여부동산 박혜경 대표의 실무 노하우가 반영된 실시간 분석 결과입니다.**

### 1. 인테리어 및 컨디션 대조
- **좌측 (${images[0].complex} ${images[0].type}):** ${images[0].space} 공간을 중심으로 시스템 에어컨 및 수납 옵션이 조화롭게 구성되어 있습니다.
- **우측 (${images[1].complex} ${images[1].type}):** ${images[1].space} 기준으로 화이트톤의 세련된 마감이 돋보이며, 실거주 만족도가 높은 구조입니다.

### 2. 공간 특성 비교
동일한 **${images[0].space}** 영역임에도 불구하고, 각 단지의 위치와 층수에 따른 개방감 차이가 시각적으로 확인됩니다. 특히 채광 효율과 가구 배치 동선을 고려할 때 각기 다른 매력을 보유하고 있습니다.

### 3. 전문가 총평
두 매물 모두 유니시티 단지 내에서 관리가 우수한 A급 컨디션입니다. 선호하시는 인테리어 톤과 실거주 인원수에 맞춘 공간 활용 계획에 따라 최적의 선택이 가능합니다.

---
**📞 상담 문의: 010-5016-3331 (박혜경 대표)**`;

    setAnalysis(report);
    setIsLoading(false);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/95 backdrop-blur-xl overflow-y-auto">
      <div className="absolute top-6 right-6 z-[110]">
        <button onClick={onClose} className="p-3 bg-white/10 hover:bg-white/20 text-white rounded-full transition-all border border-white/20 active:scale-90">
          <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" /></svg>
        </button>
      </div>
      
      <div className="w-full max-w-4xl my-auto space-y-6 py-10 fade-in">
        <div className="text-center space-y-2">
          <div className="inline-block px-3 py-1 bg-blue-500/20 rounded-full border border-blue-500/30">
            <span className="text-blue-400 text-[10px] font-black uppercase tracking-widest">Premium Analytics</span>
          </div>
          <h2 className="text-2xl md:text-4xl font-extrabold text-white tracking-tighter">매물 비교 분석 엔진</h2>
        </div>

        <div className="rounded-[2.5rem] overflow-hidden shadow-2xl border border-white/10 ring-1 ring-white/5">
          <ComparisonSlider imageLeft={images[0]} imageRight={images[1]} />
        </div>

        <div className="space-y-4">
          <button 
            onClick={generateReport} 
            disabled={isLoading} 
            className={`w-full py-5 rounded-2xl font-black text-lg transition-all shadow-xl ${
              isLoading 
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed' 
                : 'bg-white text-slate-900 hover:bg-blue-50 active:scale-95'
            }`}
          >
            {isLoading ? '분석 중...' : '전문가 비교 리포트 생성'}
          </button>

          {analysis && (
            <div className="bg-white rounded-[2.5rem] p-6 md:p-10 text-slate-800 space-y-6 shadow-2xl animate-in slide-in-from-bottom-8 duration-500">
              <div className="flex justify-between items-center border-b border-slate-100 pb-4">
                <h3 className="font-black text-xl text-blue-600 italic">OFFICIAL REPORT</h3>
                <button onClick={handleCopy} className="p-2 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors">
                  <svg className="w-5 h-5 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" /></svg>
                </button>
              </div>
              <div className="prose prose-slate max-w-none text-slate-700 whitespace-pre-wrap leading-relaxed text-sm md:text-base font-medium">
                {analysis}
              </div>
              <div className="pt-6 border-t border-slate-100">
                <a href="tel:01050163331" className="block w-full text-center bg-slate-900 text-white py-4 rounded-xl font-black hover:bg-blue-700 transition-all shadow-lg active:scale-95">
                  박혜경 대표 실시간 전화 상담
                </a>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ComparisonModal;